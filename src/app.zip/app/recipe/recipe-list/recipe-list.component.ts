import { Component } from "@angular/core";
import { Recipe } from "../../shared/model/recipe.model";
@Component({
    selector : 'ea-recipe-list',
    templateUrl : './recipe-list.component.html',
    styleUrls : ['./recipe-list.component.scss']
})

export class RecipeListComponent{
    recipeArray = [
        new Recipe ('Pohe', 'veg', 'https://myfancypantry.files.wordpress.com/2013/07/pohe.jpg', 'A moring snack popularly consumed in Maharashtra.'),
        new Recipe (' kolhapuri-misal', 'veg', 'https://images.lifestyleasia.com/wp-content/uploads/sites/7/2022/06/20174313/Untitled-design-2-18.jpg', 'Misal pav from Kolhapur is known for its high spice content and unique taste.')
    ]
}