import { Component } from '@angular/core';

@Component({
  selector: 'ea-recipe-details',
  templateUrl: './recipe-details.component.html',
  styleUrls : ['./recipe-details.component.scss']
})
export class RecipeDetailsComponent {

}
