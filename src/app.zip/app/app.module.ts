import{ HttpClientModule } from "@angular/common/http" ;
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { AppComponent } from "./app.component";
import { HeaderComponent } from "./header/header.component";
import { RecipeComponent } from "./recipe/recipe.component";
import { RecipeListComponent } from "./recipe/recipe-list/recipe-list.component";
import { RecipeDetailsComponent } from "./recipe/recipe-details/recipe-details.component";
import { RecipeItemComponenet } from "./recipe/recipe-list/recipe-item/recipe-item.component";
import { FormsModule } from "@angular/forms";


@NgModule({
    declarations : [
        AppComponent,
        HeaderComponent,
        RecipeComponent,
        RecipeListComponent,
        RecipeDetailsComponent,
        RecipeItemComponenet
    ],
    imports : [
        BrowserModule,
        HttpClientModule,
        NoopAnimationsModule,
        FormsModule
      
    ],
    providers : [],
    bootstrap : [AppComponent],
})

export class AppModule{}