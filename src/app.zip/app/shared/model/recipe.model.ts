export class Recipe {
recipeName : string;
recipeType : string;
recipeImg : string;
recipeDesc : string;


  constructor(rn : string, rt : string, ri : string, rd : string){
      this.recipeName = rn;
      this.recipeType = rt;
      this.recipeImg = ri;
      this.recipeDesc = rd;
  }

}