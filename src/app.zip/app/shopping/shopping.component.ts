import { Component } from "@angular/core";

@Component({
    selector : 'ea-shopping',
    templateUrl : './shopping.component.html',
    styleUrls : ['./shopping.component.scss']
})

export class ShoppingComponent{}